"""
orchestrator.py — Orchestrator Node for the Investigative Journalist Graph.

This module defines `orchestrator_node`, the central LangGraph node that:

1. Binds the premium ``fetch_offshore_corporate_registry`` tool to the LLM.
2. Invokes the model with the current conversation history.
3. Automatically executes any tool calls the model requests.
4. Inspects tool results — if a 402 Payment Required response is detected,
   it sets ``payment_required = True`` and populates ``invoice_details`` in
   the graph state so that downstream Procurement / Execution agents can
   negotiate an x402 payment.
"""

import json
import os

from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.messages import (
    AIMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)

from state import JournalistState
from tools import discover_articles, fetch_article

# ---------------------------------------------------------------------------
# Load environment variables (expects OPENAI_API_KEY in .env)
# ---------------------------------------------------------------------------
load_dotenv()

# ---------------------------------------------------------------------------
# System prompt — defines the journalist's persona and 402 behaviour.
# ---------------------------------------------------------------------------
SYSTEM_PROMPT = (
    "You are an elite AI Investigative Journalist for the Economic Times. "
    "Your goal is to write a briefing on the provided topic. "
    "Follow this workflow strictly:\n"
    "1. FIRST use the `discover_articles` tool with your topic to find "
    "relevant articles from the seller's catalog.\n"
    "2. Review the catalog returned (titles, summaries, prices).\n"
    "3. Decide which articles are worth purchasing for your investigation.\n"
    "4. Use the `fetch_article` tool with the article_id to access each "
    "selected article. If it returns a 402 Payment Required error, "
    "DO NOT attempt to make up data. Acknowledge the paywall and stop "
    "so the finance team can pay.\n"
    "5. After payment succeeds and data is retrieved, compile your briefing."
)

# ---------------------------------------------------------------------------
# Available tools (list used for binding & execution lookup)
# ---------------------------------------------------------------------------
TOOLS = [discover_articles, fetch_article]
_TOOL_MAP = {t.name: t for t in TOOLS}

# ---------------------------------------------------------------------------
# LLM initialisation (lazy — deferred until first call so that importing
# this module without an OPENAI_API_KEY does not block or crash).
# ---------------------------------------------------------------------------
_llm_instance = None


def _get_llm():
    """Return the tool-bound ChatOpenAI instance, creating it on first call."""
    global _llm_instance
    if _llm_instance is None:
        _llm_instance = ChatOpenAI(
            model="gpt-4o-mini",
            temperature=0,
        ).bind_tools(TOOLS)
    return _llm_instance


# ---------------------------------------------------------------------------
# Helper: execute tool calls returned by the model
# ---------------------------------------------------------------------------
def _execute_tool_calls(ai_message: AIMessage, access_token: str) -> list[ToolMessage]:
    """Run every tool call present in an AIMessage and return ToolMessages."""
    tool_messages: list[ToolMessage] = []

    for call in ai_message.tool_calls:
        tool_fn = _TOOL_MAP.get(call["name"])
        if tool_fn is None:
            # Unknown tool — return an error ToolMessage so the LLM can react
            tool_messages.append(
                ToolMessage(
                    content=json.dumps({"error": f"Unknown tool: {call['name']}"}),
                    tool_call_id=call["id"],
                )
            )
            continue

        # Inject the current access_token into the tool kwargs ONLY for fetch_article,
        # ensuring we don't crash discover_articles with unexpected kwargs.
        kwargs = dict(call["args"])
        if access_token and "access_token" not in kwargs and call["name"] == "fetch_article":
            kwargs["access_token"] = access_token
            
        result = tool_fn.invoke(kwargs)

        tool_messages.append(
            ToolMessage(content=result, tool_call_id=call["id"])
        )

    return tool_messages


# ---------------------------------------------------------------------------
# Helper: scan tool messages for a 402 response
# ---------------------------------------------------------------------------
def _detect_402(tool_messages: list[ToolMessage]) -> dict | None:
    """Return the invoice dict from the first 402 response found, or None."""
    for msg in tool_messages:
        try:
            payload = json.loads(msg.content)
            if payload.get("status") == 402:
                return payload.get("invoice", {})
        except (json.JSONDecodeError, TypeError):
            continue
    return None


# ---------------------------------------------------------------------------
# Main graph node
# ---------------------------------------------------------------------------
def orchestrator_node(state: JournalistState) -> dict:
    """LangGraph node — invokes the LLM, executes tools, and detects 402s.

    Parameters
    ----------
    state : JournalistState
        The current graph state.

    Returns
    -------
    dict
        A partial state update consumed by LangGraph's state reducer.
    """
    if state.get("topic", "").lower() == "simulate_system_failure_demo":
        raise RuntimeError("Simulated critical system failure during orchestration.")

    # ----- 1. Build the message list for the LLM -------------------------
    messages = [SystemMessage(content=SYSTEM_PROMPT)]

    # If this is the first invocation, seed the conversation with the topic.
    if not state.get("messages"):
        messages.append(
            HumanMessage(
                content=f"Write an investigative briefing on: {state['topic']}"
            )
        )
    else:
        messages.extend(state["messages"])

    # ----- 2. Autonomously execute the Agentic Loop -----------------------
    payment_required = state.get("payment_required", False)
    invoice_details = state.get("invoice_details", {})
    draft_content = state.get("draft_content", "")
    payment_attempts = state.get("payment_attempts", 0)

    new_messages: list = []
    
    max_iterations = 5
    current_iteration = 0

    while current_iteration < max_iterations:
        current_iteration += 1
        
        # Call the LLM with full context
        ai_response: AIMessage = _get_llm().invoke(messages + new_messages)
        new_messages.append(ai_response)

        if ai_response.tool_calls:
            # Execute requested tools
            tool_msgs = _execute_tool_calls(ai_response, state.get("access_token", ""))
            new_messages.extend(tool_msgs)

            # Check for a 402 Payment Required response from premium tools
            invoice = _detect_402(tool_msgs)
            if invoice:
                payment_required = True
                invoice_details = invoice
                payment_attempts += 1
                break  # Exit loop to route conditionally to Procurement Agent
            
            # If no 402, tools succeeded. The loop continues so the LLM
            # can either make another tool call or write the final draft.
        else:
            # No tool calls — the model has successfully written the article
            draft_content = ai_response.content
            break
            
    if current_iteration >= max_iterations:
        raise RuntimeError("LLM Agent exceeded maximum tool execution loop iterations.")

    # ----- 3. Return partial state update ---------------------------------
    return {
        "messages": new_messages,
        "draft_content": draft_content,
        "payment_required": payment_required,
        "invoice_details": invoice_details,
        "payment_attempts": payment_attempts,
    }
